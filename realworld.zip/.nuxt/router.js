import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _84d8b15c = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _ca12e9f2 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _77d9c37e = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _36293afe = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _49c0fe4b = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _9c7664d6 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _6894b464 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _84d8b15c,
    children: [{
      path: "",
      component: _ca12e9f2,
      name: "home"
    }, {
      path: "/register",
      component: _77d9c37e,
      name: "register"
    }, {
      path: "/login",
      component: _77d9c37e,
      name: "login"
    }, {
      path: "/profile/:username",
      component: _36293afe,
      name: "profile"
    }, {
      path: "/profile/:username/favorites",
      component: _36293afe,
      name: "favorites"
    }, {
      path: "/settings",
      component: _49c0fe4b,
      name: "settings"
    }, {
      path: "/editor",
      component: _9c7664d6,
      name: "editor"
    }, {
      path: "/editor/:slug",
      component: _9c7664d6,
      name: "updateArticle"
    }, {
      path: "/article/:slug",
      component: _6894b464,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
